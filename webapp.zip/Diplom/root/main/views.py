# main/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Test, Question, Answer, TestAttempt, UserAnswer
from django.utils import timezone
from django.db.models import Q
import json
from .forms import CustomUserCreationForm 

def home(request):
    """Главная страница"""
    return render(request, 'home.html')

def register_view(request):
    """Регистрация нового пользователя с email"""
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)  # Используем нашу форму
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f'Регистрация прошла успешно! Добро пожаловать, {user.username}!')
            return redirect('home')
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме')
    else:
        form = CustomUserCreationForm()  # Используем нашу форму
    
    return render(request, 'register.html', {'form': form})

def login_view(request):
    """Вход пользователя"""
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'С возвращением, {username}!')
                return redirect('home')
        else:
            messages.error(request, 'Неверное имя пользователя или пароль')
    else:
        form = AuthenticationForm()
    
    return render(request, 'login.html', {'form': form})
@login_required
def test_list(request):
    """Временная заглушка для списка тестов"""
    return render(request, 'test_list.html', {'tests': []})

@login_required
def test_detail(request, test_id):
    """Детальная информация о тесте перед началом"""
    test = get_object_or_404(Test, id=test_id, is_active=True)
    
    # Проверяем, сколько попыток уже использовано
    attempts_count = TestAttempt.objects.filter(
        user=request.user, 
        test=test
    ).count()
    
    attempts_left = None
    if test.attempts_allowed > 0:
        attempts_left = max(0, test.attempts_allowed - attempts_count)
        if attempts_left == 0:
            messages.error(request, 'Вы исчерпали все попытки для этого теста')
            return redirect('test_list')
    
    context = {
        'test': test,
        'attempts_count': attempts_count,
        'attempts_left': attempts_left,
        'total_questions': test.get_question_count(),
    }
    return render(request, 'test_detail.html', context)

@login_required
def start_test(request, test_id):
    """Начать прохождение теста"""
    test = get_object_or_404(Test, id=test_id, is_active=True)
    
    # Проверяем попытки
    attempts_count = TestAttempt.objects.filter(user=request.user, test=test).count()
    if test.attempts_allowed > 0 and attempts_count >= test.attempts_allowed:
        messages.error(request, 'Вы исчерпали все попытки для этого теста')
        return redirect('test_list')
    
    # Создаем новую попытку
    attempt = TestAttempt.objects.create(
        user=request.user,
        test=test,
        started_at=timezone.now()
    )
    
    return redirect('take_test', attempt_id=attempt.id)

@login_required
def take_test(request, attempt_id):
    """Прохождение теста"""
    attempt = get_object_or_404(TestAttempt, id=attempt_id, user=request.user)
    
    # Проверяем, не завершен ли тест
    if attempt.completed_at:
        messages.error(request, 'Этот тест уже завершен')
        return redirect('test_results', attempt_id=attempt.id)
    
    # Проверяем время
    if attempt.test.time_limit:
        time_passed = (timezone.now() - attempt.started_at).total_seconds() / 60
        if time_passed > attempt.test.time_limit:
            # Автоматически завершаем тест
            return redirect('submit_test', attempt_id=attempt.id)
    
    # Получаем все вопросы теста
    questions = attempt.test.questions.all()
    
    # Получаем уже отвеченные вопросы
    answered_questions = UserAnswer.objects.filter(attempt=attempt).values_list('question_id', flat=True)
    
    # Находим первый неотвеченный вопрос
    current_question = None
    for question in questions:
        if question.id not in answered_questions:
            current_question = question
            break
    
    # Если все вопросы отвечены, перенаправляем на submit
    if current_question is None:
        return redirect('submit_test', attempt_id=attempt.id)
    
    # Обработка POST (отправка ответа)
    if request.method == 'POST':
        if current_question.question_type == 'single':
            answer_id = request.POST.get('answer')
            if answer_id:
                answer = Answer.objects.get(id=answer_id)
                is_correct = answer.is_correct
                points_earned = current_question.points if is_correct else 0
                
                UserAnswer.objects.create(
                    attempt=attempt,
                    question=current_question,
                    answer=answer,
                    is_correct=is_correct,
                    points_earned=points_earned
                )
        
        elif current_question.question_type == 'multiple':
            answer_ids = request.POST.getlist('answers')
            if answer_ids:
                correct_answers = current_question.answers.filter(is_correct=True).count()
                selected_correct = current_question.answers.filter(
                    id__in=answer_ids, 
                    is_correct=True
                ).count()
                
                # Баллы пропорционально правильным ответам
                if correct_answers > 0:
                    points_earned = (selected_correct / correct_answers) * current_question.points
                else:
                    points_earned = 0
                
                # Сохраняем каждый выбранный ответ
                for answer_id in answer_ids:
                    answer = Answer.objects.get(id=answer_id)
                    UserAnswer.objects.create(
                        attempt=attempt,
                        question=current_question,
                        answer=answer,
                        is_correct=answer.is_correct,
                        points_earned=0  # Баллы начисляем отдельно
                    )
                
                # Обновляем баллы для вопроса
                UserAnswer.objects.filter(
                    attempt=attempt, 
                    question=current_question
                ).update(points_earned=points_earned)
        
        elif current_question.question_type == 'text':
            text_answer = request.POST.get('text_answer', '')
            if text_answer:
                correct_answers = current_question.text_answers.filter(is_correct=True)
                is_correct = False
                
                for correct in correct_answers:
                    if current_question.case_sensitive:
                        if text_answer == correct.correct_text:
                            is_correct = True
                            break
                    else:
                        if text_answer.lower() == correct.correct_text.lower():
                            is_correct = True
                            break
                
                points_earned = current_question.points if is_correct else 0
                
                UserAnswer.objects.create(
                    attempt=attempt,
                    question=current_question,
                    text_answer=text_answer,
                    is_correct=is_correct,
                    points_earned=points_earned
                )
        
        return redirect('take_test', attempt_id=attempt.id)
    
    # GET запрос - показываем вопрос
    context = {
        'attempt': attempt,
        'question': current_question,
        'questions_count': questions.count(),
        'answered_count': answered_questions.count(),
        'progress': int((answered_questions.count() / questions.count()) * 100),
    }
    return render(request, 'take_test.html', context)

@login_required
def submit_test(request, attempt_id):
    """Завершить тест и подсчитать результаты"""
    attempt = get_object_or_404(TestAttempt, id=attempt_id, user=request.user)
    
    if attempt.completed_at:
        return redirect('test_results', attempt_id=attempt.id)
    
    # Подсчет общего балла
    total_points = 0
    max_points = 0
    
    for question in attempt.test.questions.all():
        max_points += question.points
        user_answers = UserAnswer.objects.filter(attempt=attempt, question=question)
        
        if user_answers.exists():
            # Для multiple choice сумма баллов может быть дробной
            question_points = user_answers.first().points_earned
            total_points += question_points
    
    # Вычисляем процент
    if max_points > 0:
        score_percentage = (total_points / max_points) * 100
    else:
        score_percentage = 0
    
    attempt.score = score_percentage
    attempt.is_passed = score_percentage >= attempt.test.passing_score
    attempt.completed_at = timezone.now()
    attempt.save()
    
    messages.success(request, f'Тест завершен! Ваш результат: {score_percentage:.1f}%')
    return redirect('test_results', attempt_id=attempt.id)

@login_required
def test_results(request, attempt_id):
    """Результаты конкретной попытки"""
    attempt = get_object_or_404(TestAttempt, id=attempt_id, user=request.user)
    
    # Группируем ответы по вопросам
    questions_data = []
    for question in attempt.test.questions.all():
        user_answers = UserAnswer.objects.filter(attempt=attempt, question=question)
        correct_answers = question.answers.filter(is_correct=True) if question.question_type != 'text' else question.text_answers.filter(is_correct=True)
        
        questions_data.append({
            'question': question,
            'user_answers': user_answers,
            'correct_answers': correct_answers,
            'is_correct': any(a.is_correct for a in user_answers) if question.question_type != 'multiple' else None,
        })
    
    context = {
        'attempt': attempt,
        'questions_data': questions_data,
        'total_questions': attempt.test.questions.count(),
    }
    return render(request, 'test_results.html', context)

@login_required
def my_results(request):
    """Список всех попыток пользователя"""
    attempts = TestAttempt.objects.filter(user=request.user).order_by('-started_at')
    return render(request, 'my_results.html', {'attempts': attempts})