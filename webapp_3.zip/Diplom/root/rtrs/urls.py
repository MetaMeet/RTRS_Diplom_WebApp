""""
from django.contrib import admin
from django.urls import path
from django.shortcuts import render  
from django.contrib.auth.views import LoginView, LogoutView
from . import views

def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def test(request):
    return render(request, 'test.html')

def index(request):
    return render(request, 'index.html')

def results(request):
    return render(request, 'results.html')

def manage(request):
    return render(request, 'manage.html')

def login(request):
    return render(request, 'login.html')

def logout(request):
    return render(request, 'logout.html')

def register(request):
    return render(request, 'register.html')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),    
    path('about/', about, name='about'), 
    path('index/', index, name='index'),
    path('test/', test, name='test'), 
    path('results/', results, name='results'), 
    path('manage/', manage, name='manage'), 
    path('register/', register, name='register'), 
    path('login/', login, name='login'), 
    path('logout/', logout, name='logout'), 
]
"""
from django.contrib import admin
from django.urls import path
from django.contrib.auth.views import LogoutView
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    
    # Тесты
    path('test/<int:test_id>/', views.test_detail, name='test_detail'),
    path('test/<int:test_id>/start/', views.start_test, name='start_test'),
    path('attempt/<int:attempt_id>/take/', views.take_test, name='take_test'),
    path('attempt/<int:attempt_id>/submit/', views.submit_test, name='submit_test'),
    path('attempt/<int:attempt_id>/results/', views.test_results, name='test_results'),
    path('tests/', views.test_list, name='test_list'),
    path('my-results/', views.my_results, name='my_results'),
]
