# main/admin.py

from django.contrib import admin
from .models import Test, Question, Answer  # ИСПРАВЛЕНО!

class AnswerInline(admin.TabularInline):
    """Инлайн для ответов"""
    model = Answer
    extra = 4
    fields = ['text', 'is_correct']

class QuestionInline(admin.StackedInline):
    """Инлайн для вопросов"""
    model = Question
    extra = 1
    fields = ['text', 'points']
    show_change_link = True

@admin.register(Test)
class TestAdmin(admin.ModelAdmin):
    """Админка для тестов"""
    list_display = ['title', 'passing_score', 'time_limit', 'is_active', 'created_at']
    list_filter = ['is_active', 'created_at']
    search_fields = ['title', 'description']
    list_editable = ['is_active']
    inlines = [QuestionInline]
    
    fieldsets = (
        ('Основная информация', {
            'fields': ('title', 'description')
        }),
        ('Настройки теста', {
            'fields': ('time_limit', 'passing_score', 'is_active')
        }),
    )

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    """Админка для вопросов"""
    list_display = ['id', 'test', 'text_short', 'points']
    list_filter = ['test']
    search_fields = ['text']
    list_editable = ['points']
    inlines = [AnswerInline]
    
    def text_short(self, obj):
        return obj.text[:50] + '...' if len(obj.text) > 50 else obj.text
    text_short.short_description = 'Вопрос'

@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    """Админка для ответов"""
    list_display = ['id', 'question', 'text_short', 'is_correct']
    list_filter = ['is_correct', 'question__test']
    search_fields = ['text']
    list_editable = ['is_correct']
    
    def text_short(self, obj):
        return obj.text[:30] + '...' if len(obj.text) > 30 else obj.text
    text_short.short_description = 'Ответ'
    