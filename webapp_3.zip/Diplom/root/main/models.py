# main/models.py
"""
from django.db import models

class Test(models.Model):
    title = models.CharField('Название теста', max_length=200)
    description = models.TextField('Описание', blank=True)
    time_limit = models.IntegerField('Лимит времени (минуты)', null=True, blank=True)
    passing_score = models.IntegerField('Проходной балл', default=70)
    created_at = models.DateTimeField('Дата создания', auto_now_add=True)
    is_active = models.BooleanField('Активен', default=True)

    def __str__(self):
        return self.title

class Question(models.Model):
    test = models.ForeignKey(Test, on_delete=models.CASCADE, verbose_name='Тест')
    text = models.TextField('Текст вопроса')
    points = models.IntegerField('Баллы', default=1)

    def __str__(self):
        return self.text[:50]

class Answer(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, verbose_name='Вопрос')
    text = models.CharField('Текст ответа', max_length=500)
    is_correct = models.BooleanField('Правильный ответ', default=False)

    def __str__(self):
        return self.text[:30]
    """
# main/models.py
from django.db import models
from django.contrib.auth.models import User

class Test(models.Model):
    """Модель теста"""
    title = models.CharField('Название теста', max_length=200)
    description = models.TextField('Описание', blank=True)
    time_limit = models.IntegerField('Лимит времени (минуты)', null=True, blank=True)
    attempts_allowed = models.IntegerField('Количество попыток', default=1)
    passing_score = models.IntegerField('Проходной балл', default=70)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField('Дата создания', auto_now_add=True)
    updated_at = models.DateTimeField('Дата обновления', auto_now=True)
    is_active = models.BooleanField('Активен', default=True)

    class Meta:
        verbose_name = 'Тест'
        verbose_name_plural = 'Тесты'

    def __str__(self):
        return self.title
    
    def get_question_count(self):
        return self.questions.count()

class Question(models.Model):
    """Модель вопроса"""
    QUESTION_TYPES = [
        ('single', 'Один правильный ответ'),
        ('multiple', 'Несколько правильных ответов'),
        ('text', 'Текстовый ответ'),
    ]
    
    test = models.ForeignKey(Test, on_delete=models.CASCADE, related_name='questions', verbose_name='Тест')
    question_type = models.CharField('Тип вопроса', max_length=20, choices=QUESTION_TYPES, default='single')
    text = models.TextField('Текст вопроса')
    points = models.IntegerField('Баллы', default=1)
    order = models.IntegerField('Порядок', default=0)
    case_sensitive = models.BooleanField('Учитывать регистр', default=False)

    class Meta:
        verbose_name = 'Вопрос'
        verbose_name_plural = 'Вопросы'
        ordering = ['order', 'id']

    def __str__(self):
        return f"{self.test.title} - {self.text[:50]}..."

class Answer(models.Model):
    """Модель ответа для выбора"""
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='answers', verbose_name='Вопрос')
    text = models.CharField('Текст ответа', max_length=500)
    is_correct = models.BooleanField('Правильный ответ', default=False)
    order = models.IntegerField('Порядок', default=0)

    class Meta:
        verbose_name = 'Ответ'
        verbose_name_plural = 'Ответы'
        ordering = ['order', 'id']

    def __str__(self):
        return f"{self.text[:30]}... {'✓' if self.is_correct else ''}"

class TextAnswer(models.Model):
    """Модель для правильных текстовых ответов"""
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='text_answers', verbose_name='Вопрос')
    correct_text = models.TextField('Правильный текст ответа')
    is_correct = models.BooleanField('Является правильным', default=True)

    class Meta:
        verbose_name = 'Текстовый ответ'
        verbose_name_plural = 'Текстовые ответы'

    def __str__(self):
        return self.correct_text[:50]

class TestAttempt(models.Model):
    """Модель попытки прохождения теста"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='test_attempts', verbose_name='Пользователь')
    test = models.ForeignKey(Test, on_delete=models.CASCADE, related_name='attempts', verbose_name='Тест')
    started_at = models.DateTimeField('Начало', auto_now_add=True)
    completed_at = models.DateTimeField('Завершение', null=True, blank=True)
    score = models.FloatField('Результат', null=True, blank=True)
    is_passed = models.BooleanField('Тест сдан', default=False)

    class Meta:
        verbose_name = 'Попытка теста'
        verbose_name_plural = 'Попытки тестов'
        ordering = ['-started_at']

    def __str__(self):
        return f"{self.user.username} - {self.test.title} ({self.started_at})"

class UserAnswer(models.Model):
    """Модель ответа пользователя"""
    attempt = models.ForeignKey(TestAttempt, on_delete=models.CASCADE, related_name='user_answers', verbose_name='Попытка')
    question = models.ForeignKey(Question, on_delete=models.CASCADE, verbose_name='Вопрос')
    answer = models.ForeignKey(Answer, on_delete=models.CASCADE, null=True, blank=True, verbose_name='Выбранный ответ')
    text_answer = models.TextField('Текстовый ответ', blank=True)
    is_correct = models.BooleanField('Правильно', default=False)
    points_earned = models.FloatField('Получено баллов', default=0)

    class Meta:
        verbose_name = 'Ответ пользователя'
        verbose_name_plural = 'Ответы пользователей'